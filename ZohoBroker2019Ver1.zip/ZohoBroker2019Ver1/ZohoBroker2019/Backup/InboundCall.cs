﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Xml;
using System.Net;
using System.IO;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Threading;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Security.Cryptography;

[assembly: ComVisible(false)]
namespace ZohoBroker
{
    public class InboundCall : IDisposable
    {
        private bool Answered;
        private string CallWaiting;
        public string GetUrl()
        {
            string url = "https://crm.zoho.com/";
            return url;
        }
        private int AgentID;
        public int CompanyID;
        private int companyid;
        private string username;
        private string address;
        private string sSource;
        private string sLog;
        public string ANI;
        private string DNIS;
        private string SesId;
        private string Ip;
        private int Duration;
        private string custNumber;
        private Encryptor oEncryptor;
        private string Encrypted;
        private string AutThoken;
        private string Instance;
        private XmlDocument myXMLUsers = null;
        private readonly static string unreservedCharacters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_.~";
        //private string path = @"c:\temp\Zohoclid2Dial.txt";
        public string connString;
        public string instance;
        public string uri;
        internal string Helloworld(string INITD, string interactionType, int agentID)
        {
            string res = GetZohoUser(agentID);
            res = "INITD: " + INITD + " interactionType:" + interactionType + " Address: " + res;
            return res;
        }
        public string Helloworld()
        {
            oEncryptor = new Encryptor();
            string res = oEncryptor.Encrypt("Hello", "BYdlOp8FqaSUzsgk");
            if (res == "eyw6dW9FRz1K/pk+h4Ulrw==") res = "Success";
            string res2 = oEncryptor.Encrypt("1419302695Callrefid61480456123412016543210", "BYdlOp8FqaSUzsgk");
            if (res2 == "g/z4dlGDWP2iPxvIbD2xvsyqeOjYsNFp6zS4o9C1ENMGnAXDlsFSZtMrEuer08o4") res = res + "  Success";

            return res;
        }
        public string GetZohoUser(int agentID)
        {
            string Res = "";
            try
            {
                using (var conn = new SqlConnection(connString))
                {
                    using (SqlCommand cmdCheck = new SqlCommand("ZohoGetUser", conn))
                    {
                        cmdCheck.CommandType = CommandType.StoredProcedure;
                        cmdCheck.Parameters.AddWithValue("@UserId", agentID);
                        conn.Open();
                        using (var dataReader = cmdCheck.ExecuteReader())
                        {
                            if (dataReader.HasRows)
                            {
                                dataReader.Read();
                                username = (string)dataReader[0];
                                address = (string)dataReader[1];
                                companyid = (int)dataReader[2];
                                Res = username + " " + address;
                            }
                        }
                    }
                }
                return Res;
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
                return "";
            }

        }

        public string GetBillinPeojectANI(string userid)
        {
            try
            {
                SqlDataReader oDataReader;
                string a = "";
                string result;
                //Select callerid from projects where companyid = 1 and projectid = (Select DefaultBillingProjectId From users where userid = 10803 and address = '1381463000000078001')
                using (var conn = new SqlConnection(connString))
                {
                    using (SqlCommand cmdCheck = new SqlCommand("Select address, companyid From Users Where userid = @User", conn))
                    {
                        conn.Open();
                        cmdCheck.CommandType = CommandType.Text;
                        cmdCheck.Parameters.AddWithValue("@User", userid);
                        oDataReader = cmdCheck.ExecuteReader();
                        oDataReader.Read();
                        if (oDataReader.HasRows) { a = (string)oDataReader[0]; this.companyid = (int)oDataReader[1]; }
                        else { a = ""; this.companyid = -1; }
                        conn.Close();
                    }
                    using (SqlCommand cmdCheck1 = new SqlCommand("Select callerid from projects where companyid = " + this.companyid + " and projectid = (Select DefaultBillingProjectId From users where userid = @AgentId and address = @UserId)", conn))
                    {
                        conn.Open();
                        cmdCheck1.Parameters.AddWithValue("@AgentId", userid);
                        cmdCheck1.Parameters.AddWithValue("@UserId", a);
                        result = (string)cmdCheck1.ExecuteScalar();
                        //conn.Close();
                    }
                }
                return result;
            }
            catch (Exception ex)
            {
                WriteEvent(ex.Message);
                return "";
            }

        }

        public string GetZohoUserName(string userid)
        {
            string Res = "";
            try
            {
                using (var conn = new SqlConnection(connString))
                {
                    using (SqlCommand cmdCheck = new SqlCommand("Select username From users where address = @userid", conn))
                    {
                        cmdCheck.Parameters.Clear();
                        cmdCheck.Parameters.AddWithValue("@userid", userid);
                        cmdCheck.CommandType = CommandType.Text;
                        conn.Open();
                        using (var dataReader = cmdCheck.ExecuteReader())
                        {
                            if (dataReader.HasRows)
                            {
                                dataReader.Read();
                                this.username = (string)dataReader[0];
                            }
                        }
                    }
                }
                return Res;
            }
            catch (Exception)
            {
                throw;
            }

        }

        public String APIMethod(string modulename, string methodname, string type, int opt)
        {
            url = GetUrl();
            if ((type == "GET" && opt == 0) || (opt == 1)) uri = url + modulename + "/" + methodname + "?";
            else uri = url + modulename + "/" + methodname;
            TimeSpan t = DateTime.UtcNow - new DateTime(1970, 1, 1);
            ctime = (int)t.TotalSeconds;
            oEncryptor = new Encryptor();
            Encrypted = oEncryptor.Encrypt(ctime.ToString() + SesId + DNIS + ANI, "6Ryx5m4Ggdy2z0Ec");
            Encrypted = UrlEncode(Encrypted);
            GetZohoUser(agentID);
            string postContent = "";
            switch (methodname)
            {
                case "users":
                    postContent = postContent + "phonebridgekey=6Ryx5m4Ggdy2z0Ec";
                    postContent = postContent + "&authtoken=" + this.AutThoken;
                    break;
                case "phonebridge":
                    postContent = postContent + "phonebridgekey=6Ryx5m4Ggdy2z0Ec";
                    postContent = postContent + "&authtoken=" + this.AutThoken;
                    postContent = postContent + "&tpiauthtoke=" + this.AutThoken;
                    break;
                case "callreceived":
                    postContent = postContent + "phonebridgekey=6Ryx5m4Ggdy2z0Ec";
                    postContent = postContent + "&authtoken=" + this.AutThoken;
                    postContent = postContent + "&encryptedvalue=" + Encrypted;
                    postContent = postContent + "&currenttime=" + ctime.ToString(); //1419302695";
                    postContent = postContent + "&callrefid=" + SesId;
                    postContent = postContent + "&phonebridgenumber=" + DNIS;
                    postContent = postContent + "&customernumber=" + ANI;
                    postContent = postContent + "&userid=" + address;
                    break;
                case "callanswered":
                    postContent = postContent + "phonebridgekey=6Ryx5m4Ggdy2z0Ec";
                    postContent = postContent + "&authtoken=" + this.AutThoken;
                    postContent = postContent + "&encryptedvalue=" + Encrypted;
                    postContent = postContent + "&currenttime=" + ctime.ToString(); //1419302695";
                    postContent = postContent + "&callrefid=" + SesId;
                    postContent = postContent + "&phonebridgenumber=" + DNIS;
                    postContent = postContent + "&customernumber=" + ANI;
                    postContent = postContent + "&userid=" + address;
                    postContent = postContent + "&callbackparam=None";
                    if (opt == 0)
                    {
                        postContent = postContent + "&direction=inbound";
                    }
                    else
                    {
                        postContent = postContent + "&direction=outbound";
                    }
                    break;
                case "callhungup":
                    postContent = postContent + "phonebridgekey=6Ryx5m4Ggdy2z0Ec";
                    postContent = postContent + "&authtoken=" + this.AutThoken;
                    postContent = postContent + "&encryptedvalue=" + Encrypted;
                    postContent = postContent + "&currenttime=" + ctime.ToString(); //1419302695";
                    postContent = postContent + "&callrefid=" + SesId;
                    postContent = postContent + "&phonebridgenumber=" + DNIS;
                    postContent = postContent + "&customernumber=" + ANI;
                    postContent = postContent + "&userid=" + address;
                    if (opt == 0)
                    {
                        postContent = postContent + "&direction=inbound";
                    }
                    else
                    {
                        postContent = postContent + "&direction=outbound";
                    }
                    postContent = postContent + "&duration=" + Duration.ToString();
                    postContent = postContent + "&recordingurl=";
                    break;
                case "callmissed":
                    postContent = postContent + "phonebridgekey=6Ryx5m4Ggdy2z0Ec";
                    postContent = postContent + "&authtoken=" + this.AutThoken;
                    postContent = postContent + "&encryptedvalue=" + Encrypted;
                    postContent = postContent + "&currenttime=" + ctime.ToString(); //1419302695";
                    postContent = postContent + "&callrefid=" + SesId;
                    postContent = postContent + "&phonebridgenumber=" + DNIS;
                    postContent = postContent + "&customernumber=" + ANI;
                    postContent = postContent + "&userid=" + address;
                    if (opt == 0)
                    {
                        postContent = postContent + "&direction=inbound";
                    }
                    else
                    {
                        postContent = postContent + "&direction=outbound";
                    }
                    postContent = postContent + "&duration=" + Duration.ToString();
                    postContent = postContent + "&voicemailurl=";
                    break;
                case "calldialed":
                    postContent = postContent + "phonebridgekey=6Ryx5m4Ggdy2z0Ec";
                    postContent = postContent + "&authtoken=" + this.AutThoken;
                    postContent = postContent + "&encryptedvalue=" + Encrypted;
                    postContent = postContent + "&currenttime=" + ctime.ToString(); //1419302695";
                    postContent = postContent + "&callrefid=" + SesId;
                    postContent = postContent + "&phonebridgenumber=" + DNIS;
                    postContent = postContent + "&customernumber=" + this.custNumber;
                    postContent = postContent + "&userid=" + this.address;
                    postContent = postContent + "&callbackparam=";
                    break;
                case "OutboundCall":
                    //http://cca.promero.com/taw/ProxyDial?companyId=1&username=atorres&telephone=9549358810&countrycode=1&dialok=www.google.com&dialerror=www.yahoo.com            
                    switch (this.instance)
                    {
                        case "HQ":
                            uri = "http://cca.promero.com/taw/ProxyDial";
                            break;
                        case "PODC":
                            uri = "http://cca.c.promero.com/taw/ProxyDial";
                            break;
                        case "PODA":
                            uri = "http://cca.a.promero.com/taw/ProxyDial";
                            break;
                        default:
                            break;
                    }

                    postContent = "companyId=" + this.companyid;
                    postContent = postContent + "&username=" + this.username;
                    postContent = postContent + "&telephone=" + this.custNumber;
                    postContent = postContent + "&countrycode=1";
                    postContent = postContent + "&dialok=www.yahoo.com";
                    postContent = postContent + "&dialerror=www.yahoo.com";
                    break;
                default:
                    break;
            }
            string result;
            result = AccessCRM(uri, postContent, methodname, type);
            WriteLog(methodname, opt, result);
            return result;
        }

        public static string UrlEncode(string value)
        {
            if (String.IsNullOrEmpty(value))
                return String.Empty;

            var sb = new StringBuilder();

            foreach (char @char in value)
            {
                if (unreservedCharacters.IndexOf(@char) != -1)
                    sb.Append(@char);
                else
                    sb.AppendFormat("%{0:x2}", (int)@char);
            }
            return sb.ToString();
        }

        public void WriteLog(string methodname, int opt, string result)
        {
            switch (methodname)
            {
                case "users":
                    WriteEvent("Call API users: " + Environment.NewLine + Environment.NewLine + "phonebridgekey=6Ryx5m4Ggdy2z0Ec"
                                                  + Environment.NewLine + "authtoken=" + this.AutThoken
                                                  + Environment.NewLine + "Result: " + result);
                    break;
                case "phonebridge":
                    WriteEvent("Call API phonebridge: " + Environment.NewLine + Environment.NewLine + "phonebridgekey=6Ryx5m4Ggdy2z0Ec"
                                                        + Environment.NewLine + "authtoken=" + this.AutThoken
                                                        + Environment.NewLine + "tpiauthtoken=" + this.AutThoken
                                                        + Environment.NewLine + "Result: " + result);
                    break;
                case "callreceived":
                    WriteEvent("Call API callreceived: " + Environment.NewLine + Environment.NewLine + "phonebridgekey=6Ryx5m4Ggdy2z0Ec"
                                                         + Environment.NewLine + "authtoken=" + this.AutThoken
                                                         + Environment.NewLine + "currenttime=" + ctime.ToString()
                                                         + Environment.NewLine + "callrefid=" + SesId
                                                         + Environment.NewLine + "phonebridgenumber=" + DNIS
                                                         + Environment.NewLine + "customernumber=" + ANI
                                                         + Environment.NewLine + "userid=" + address
                                                         + Environment.NewLine + "Result: " + result);

                    break;
                case "callanswered":
                    WriteEvent("Call API callanswered: " + Environment.NewLine + Environment.NewLine + "phonebridgekey=6Ryx5m4Ggdy2z0Ec"
                                                         + Environment.NewLine + "authtoken=" + this.AutThoken
                                                         + Environment.NewLine + "encryptedvalue=" + Encrypted
                                                         + Environment.NewLine + "currenttime=" + ctime.ToString()
                                                         + Environment.NewLine + "callrefid=" + SesId
                                                         + Environment.NewLine + "phonebridgenumber=" + DNIS
                                                         + Environment.NewLine + "customernumber=" + ANI
                                                         + Environment.NewLine + "userid=" + address
                                                         + Environment.NewLine + "callbackparam=None"
                                                         + Environment.NewLine + (opt == 0 ? "direction=inbound" : "direction=outbound")
                                                         + Environment.NewLine + "Result: " + result);
                    break;
                case "callhungup":
                    WriteEvent("Call API callhungup: " + Environment.NewLine + Environment.NewLine + "phonebridgekey=6Ryx5m4Ggdy2z0Ec"
                                                       + Environment.NewLine + "authtoken=" + this.AutThoken
                                                       + Environment.NewLine + "encryptedvalue=" + Encrypted
                                                       + Environment.NewLine + "currenttime=" + ctime.ToString()
                                                       + Environment.NewLine + "callrefid=" + SesId
                                                       + Environment.NewLine + "phonebridgenumber=" + DNIS
                                                       + Environment.NewLine + "customernumber=" + ANI
                                                       + Environment.NewLine + "userid=" + address
                                                       + Environment.NewLine + (opt == 0 ? "direction=inbound" : "direction=outbound")
                                                       + Environment.NewLine + "duration=" + Duration.ToString()
                                                       + Environment.NewLine + "recordingurl="
                                                       + Environment.NewLine + "Result: " + result);
                    break;
                case "callmissed":
                    WriteEvent("Call API callmissed: " + Environment.NewLine + Environment.NewLine + "phonebridgekey=6Ryx5m4Ggdy2z0Ec"
                                                       + Environment.NewLine + "authtoken=" + this.AutThoken
                                                       + Environment.NewLine + "encryptedvalue=" + Encrypted
                                                       + Environment.NewLine + "currenttime=" + ctime.ToString()
                                                       + Environment.NewLine + "callrefid=" + SesId
                                                       + Environment.NewLine + "phonebridgenumber=" + DNIS
                                                       + Environment.NewLine + "customernumber=" + ANI
                                                       + Environment.NewLine + "userid=" + address
                                                       + Environment.NewLine + (opt == 0 ? "direction=inbound" : "direction=outbound")
                                                       + Environment.NewLine + "duration=" + Duration.ToString()
                                                       + Environment.NewLine + "voicemailurl="
                                                       + Environment.NewLine + "Result: " + result);
                    break;
                case "calldialed":
                    WriteEvent("Call API calldialed: " + Environment.NewLine + Environment.NewLine + "phonebridgekey=6Ryx5m4Ggdy2z0Ec"
                                                       + Environment.NewLine + "authtoken=" + this.AutThoken
                                                       + Environment.NewLine + "encryptedvalue=" + Encrypted
                                                       + Environment.NewLine + "currenttime=" + ctime.ToString()
                                                       + Environment.NewLine + "callrefid=" + SesId
                                                       + Environment.NewLine + "phonebridgenumber=" + DNIS
                                                       + Environment.NewLine + "customernumber=" + ANI
                                                       + Environment.NewLine + "userid=" + address
                                                       + Environment.NewLine + "callbackparam="
                                                       + Environment.NewLine + "Result: " + result);

                    break;
                case "OutboundCall":
                    WriteEvent("Make outbound call to telephone=" + this.custNumber + Environment.NewLine + Environment.NewLine
                                                                  + Environment.NewLine + "uri = " + uri
                                                                  + Environment.NewLine + "postContent = companyId=" + this.companyid
                                                                  + Environment.NewLine + "&username=" + username
                                                                  + Environment.NewLine + "&telephone=" + this.custNumber
                                                                  + Environment.NewLine + "&countrycode=1"
                                                                  + Environment.NewLine + "&dialok=www.yahoo.com"
                                                                  + Environment.NewLine + "&dialerror=www.yahoo.com");
                    break;
                default:
                    break;
            }
        }

        public string AccessCRM(string url, string postcontent, string methodname, string type)
        {
            string result = "";
            string resultf = "";
            XmlDocument myXMLDocument = null;
            try
            {
                if (type == "POST")
                {
                    //postcontent = UrlEncode(postcontent);
                    WebRequest Request = WebRequest.Create(url);
                    Request.Method = "POST";
                    UTF8Encoding encoding = new UTF8Encoding();
                    byte[] byte1 = encoding.GetBytes(postcontent);
                    Request.ContentType = "application/x-www-form-urlencoded";
                    Request.ContentLength = byte1.Length;
                    Stream response = Request.GetRequestStream();
                    response.Write(byte1, 0, byte1.Length);
                    response.Close();
                    WebResponse myWebResponse = Request.GetResponse();
                    using (var reader = new StreamReader(myWebResponse.GetResponseStream()))
                    {
                        resultf = reader.ReadToEnd(); // do something fun...
                    }
                    myXMLDocument = new XmlDocument();
                    myXMLDocument.LoadXml(resultf);
                }
                else
                {
                    myXMLDocument = new XmlDocument();
                    myXMLDocument.Load(url + postcontent);
                }
                myXMLDocument.RemoveChild(myXMLDocument.FirstChild);
                foreach (XmlElement item in myXMLDocument)
                {
                    if (item.Name == "response")
                    {
                        XmlNode oResponse = item;
                        XmlNode oResponseR = item.FirstChild;
                        XmlNode oResponseA = oResponseR.FirstChild;
                        if (oResponseA.Value == "SUCCESS")
                        {
                            result = "Success";
                            if (methodname == "users")
                            {
                                myXMLUsers = myXMLDocument;
                            }
                        }
                        else
                        {
                            string reason;
                            if (oResponseR.NextSibling != null) reason = oResponseR.NextSibling.LastChild.Value;
                            else reason = oResponseA.Value;
                            result = "Failure, " + reason;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                result = e.Message;
            }

            return result;
        }

        public int agentID { get; set; }

        public string WaitForAction(string INITD, int opt, string ANI, int CompanyID)
        {
            WriteEvent("Winting for action with INITD: " + INITD + " opt: " + opt + " and ANI: " + ANI + " and connString: " + connString);
            CallWaiting = "Call" + INITD;
            if (opt == 0)
            {
                while (!CallAnswered(INITD, opt, ANI, CompanyID) && !CallMissed(INITD, CompanyID) && !CallHangup(INITD, opt, ANI, CompanyID))
                {
                }
            }
            else
            {
                this.DNIS = "9549358800";
                while (!CallAnswered(INITD, opt, ANI, CompanyID) && !CallHangup(INITD, opt, ANI, CompanyID))
                {
                }
            }
            if (Answered)
            {
                while (!CallHangup(INITD, opt, ANI, CompanyID))
                {
                }
            }
            return "Done!";
        }

        internal void WriteEvent(string Event)
        {
            sSource = "ZohoBroker";
            sLog = "Application";
            if (!EventLog.SourceExists(sSource)) EventLog.CreateEventSource(sSource, sLog);
            EventLog.WriteEntry(sSource, Event, EventLogEntryType.Information, agentID);
        }

        internal string CallReceived(string interType, int agentID, string ANI, string DNIS, string SesID, string ip)
        {
            this.SesId = SesID;
            this.ANI = ANI;
            this.DNIS = DNIS;
            this.AgentID = agentID;
            this.Ip = ip;
            GetZohoUser(agentID);
            string res = "";
            url = "https://crm.zoho.com/";
            if (interType != "13")
            {
                string result1 = APIMethod("phonebridgeapi", "users", "GET", 0);
                WriteEvent("The users api call result was " + result1);
                res = APIMethod("phonebridgeapi", "callreceived", "POST", 0);
                WriteEvent("A call was received and the api call result was " + res);
            }
            return res;
        }

        public bool CallAnswered(string INITD, int opt, string ANI, int CompanyID)
        {
            try
            {
                bool res = false;
                using (var conn = new SqlConnection(connString))
                {
                    const string masterSelectQuery = "ZohoDaemon";
                    using (var command = new SqlCommand(masterSelectQuery, conn))
                    {
                        conn.Open();
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add("@InteractionId", SqlDbType.VarChar).Value = INITD;
                        if (opt == 0) command.Parameters.Add("@Type", SqlDbType.Int).Value = 70011;
                        else command.Parameters.Add("@Type", SqlDbType.Int).Value = 70005;
                        command.Parameters.Add("@option", SqlDbType.Int).Value = 0;
                        command.Parameters.Add("@CompanyID", SqlDbType.Int).Value = CompanyID;
                        string cRes;
                        using (var dataReader = command.ExecuteReader())
                        {
                            dataReader.Read();
                            if (dataReader.HasRows)
                            {
                                if (opt == 1)
                                {
                                    this.ANI = ANI;
                                    this.SesId = "CallRef" + this.ANI;
                                }
                                cRes = APIMethod("phonebridgeapi", "callanswered", "POST", opt);
                                WriteEvent("The interactionid: " + INITD.ToString() + " Was answered and the api call result was " + cRes);

                                res = true;
                                Answered = true;
                            }
                        }
                    }
                }
                return res;
            }
            catch (Exception ex)
            {
                WriteEvent("Error Checking answered call: " + ex.Message);
                throw;
            }

        }

        public bool CallHangup(string INITD, int opt, string ANI, int CompanyID)
        {
            try
            {
                bool res = false;
                using (var conn = new SqlConnection(connString))
                {
                    const string masterSelectQuery = "ZohoDaemon";
                    using (var command = new SqlCommand(masterSelectQuery, conn))
                    {
                        conn.Open();
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add("@InteractionId", SqlDbType.VarChar).Value = INITD;
                        command.Parameters.Add("@Type", SqlDbType.Int).Value = 70002;
                        command.Parameters.Add("@option", SqlDbType.Int).Value = 0;
                        command.Parameters.Add("@CompanyID", SqlDbType.Int).Value = CompanyID;

                        string cRes;
                        using (var dataReader = command.ExecuteReader())
                        {
                            dataReader.Read();
                            if (dataReader.HasRows)
                            {
                                Duration = (int)dataReader[1];
                                if (opt == 1)
                                {
                                    this.ANI = ANI;
                                    this.SesId = "CallRef" + this.ANI;
                                }
                                cRes = APIMethod("phonebridgeapi", "callhungup", "POST", opt);
                                WriteEvent("The interactionid: " + INITD.ToString() + " Was hangup and the api call result was " + cRes);
                                res = true;
                                Answered = false;
                            }
                        }
                    }
                }
                return res;
            }
            catch (Exception ex)
            {
                WriteEvent("Error Checking hangup call: " + ex.Message);
                throw;

            }

        }

        public bool CallMissed(string INITD, int CompanyID)
        {
            try
            {
                bool res = false;
                using (var conn = new SqlConnection(connString))
                {
                    using (SqlCommand cmdCheck = new SqlCommand("ZohoDaemon", conn))
                    {
                        cmdCheck.CommandType = CommandType.StoredProcedure;
                        cmdCheck.Parameters.AddWithValue("@InteractionId", INITD);
                        cmdCheck.Parameters.AddWithValue("@Type", 70053);
                        cmdCheck.Parameters.AddWithValue("@option", 1);
                        cmdCheck.Parameters.Add("@CompanyID", SqlDbType.Int).Value = CompanyID;

                        conn.Open();
                        string cRes;
                        using (var dataReader = cmdCheck.ExecuteReader())
                        {
                            if (dataReader.HasRows)
                            {
                                dataReader.Read();
                                Duration = (int)dataReader[1];
                                cRes = APIMethod("phonebridgeapi", "callmissed", "POST", 0);
                                WriteEvent("The interactionid: " + INITD.ToString() + " Was missed and the api call result was " + cRes);
                                res = true;
                            }
                            else res = false;
                            Answered = false;
                        }
                    }
                }
                return res;
            }
            catch (Exception ex)
            {
                WriteEvent("Error Checking missed call: " + ex.Message);
                throw;

            }
        }

        public string CallDailed(string userid, string custNumber, HttpRequest request, string instance)
        {
            try
            {
                custNumber = custNumber.Replace("(", "");
                custNumber = custNumber.Replace(")", "");
                custNumber = custNumber.Replace(" ", "");
                custNumber = custNumber.Replace("-", "");
                GetZohoUserName(userid);
                this.address = userid;
                url = "https://crmservices.zohosqa.com/";
                this.custNumber = custNumber;
                this.ANI = this.custNumber;
                this.DNIS = "9549358800";
                this.SesId = "CallRef" + this.ANI;
                this.instance = instance;
                string res3 = APIMethod("phonebridgeapi", "OutboundCall", "POST", 0);
                return "";
            }
            catch (Exception ex)
            {
                WriteEvent("Error Making a click2dial call: " + ex.Message);
                throw;
            }

        }

        #region IDisposable implementation

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        private bool m_Disposed = false;
        private int ctime;
        private string url;

        protected virtual void Dispose(bool disposing)
        {
            if (!m_Disposed)
            {
                if (disposing)
                {

                    // Unmanaged resources are released here.
                    oEncryptor.Dispose();
                    m_Disposed = true;
                }
            }
        }

        ~InboundCall()
        {
            Dispose(false);
        }

        #endregion


        internal string CallDailedCCA(string userid, string custNumber, HttpRequest request, int option, int CompanyID)
        {
            WriteEvent("Interaction type: " + request.Form["interactionType"]);
            string res = "";
            custNumber = custNumber.Replace("(", "");
            custNumber = custNumber.Replace(")", "");
            custNumber = custNumber.Replace(" ", "");
            custNumber = custNumber.Replace("-", "");
            GetZohoUserName(userid);
            this.address = userid;
            url = "https://crmservices.zohosqa.com/";
            this.custNumber = custNumber;
            if (option != 999) this.ANI = this.custNumber;
            else this.ANI = custNumber;
            this.DNIS = GetBillinPeojectANI(userid);
            this.SesId = "CallRef" + this.ANI;
            //if (!File.Exists(path)) res = APIMethod("phonebridgeapi", "calldialed", "POST", 0);
            res = APIMethod("phonebridgeapi", "calldialed", "POST", 0);
            res = WaitForAction(request.Form["interactionId"].ToString(), 1, ANI, CompanyID);
            return res;
        }

        internal string CheckAccountstatus(string UserId, int Option)
        {
            WriteEvent("Checking Company Status");
            WriteEvent("connString: " + connString);
            WriteEvent("Userid: " + UserId + " option: " + Option.ToString());
            string Res = "Invalid";
            try
            {
                using (var conn = new SqlConnection(connString))
                {
                    if (Option == 0)
                    {
                        using (SqlCommand cmdCheck = new SqlCommand("Select companyid from users where userid = @Userid", conn))
                        {
                            cmdCheck.CommandType = CommandType.Text;
                            cmdCheck.Parameters.AddWithValue("@Userid", UserId);
                            conn.Open();
                            this.companyid = (int)cmdCheck.ExecuteScalar();
                        }
                    }
                    else
                    {
                        using (SqlCommand cmdCheck = new SqlCommand("Select companyid from users where address = @address", conn))
                        {
                            cmdCheck.CommandType = CommandType.Text;
                            cmdCheck.Parameters.AddWithValue("@address", UserId);
                            conn.Open();
                            object temp = cmdCheck.ExecuteScalar();
                            if ((temp == null) || (temp == DBNull.Value)) this.companyid = -1000;
                            else this.companyid = (int)temp;
                        }
                    }
                    WriteEvent("Company: " + this.companyid);
                }

                using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["connStringMain"].ConnectionString))
                {
                    using (SqlCommand cmdCheck = new SqlCommand("ZohoAccountStatus", conn))
                    {
                        cmdCheck.CommandType = CommandType.StoredProcedure;
                        cmdCheck.Parameters.AddWithValue("@companyid", this.companyid);
                        conn.Open();
                        SqlDataReader oDatareader = cmdCheck.ExecuteReader();
                        oDatareader.Read();
                        if (oDatareader.HasRows)
                        {
                            Res = (string)oDatareader[0];
                            AutThoken = (string)oDatareader[1];
                            Instance = (string)oDatareader[2];
                        }
                        WriteEvent("Status: " + Res);
                        WriteEvent("AutThoken: " + AutThoken);
                    }
                }

            }
            catch (Exception ex)
            {
                WriteEvent("Checking Status Error: " + ex.Message);
            }
            return Res;

        }

    }
}