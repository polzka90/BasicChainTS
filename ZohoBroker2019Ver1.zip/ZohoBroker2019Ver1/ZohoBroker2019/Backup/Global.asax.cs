﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Diagnostics;
using System.Xml;
using System.Net;
using System.Text;
using System.IO;
using System.Configuration;

namespace ZohoBroker
{
    public class Global : System.Web.HttpApplication
    {
        public InboundCall oInboundCall = new InboundCall();
        private string res;
        private string path = @"c:\temp\Zohoclid2Dial.txt";
        void Application_End(object sender, EventArgs e)
        {
            //  Code that runs on application shutdown

        }

        void Application_Error(object sender, EventArgs e)
        {
            // Code that runs when an unhandled error occurs

        }

        void Session_Start(object sender, EventArgs e)
        {
            WebPageTraceListener gbTraceListener = new WebPageTraceListener();
            System.Diagnostics.Trace.Listeners.Add(gbTraceListener);
            // Code that runs when a new session is started
            Response.Write("Welcome To Zoho Integration with WorkGroup Calls");


        }

        void Session_End(object sender, EventArgs e)
        {
            // Code that runs when a session ends. 
            // Note: The Session_End event is raised only when the sessionstate mode
            // is set to InProc in the Web.config file. If session mode is set to StateServer 
            // or SQLServer, the event is not raised.

        }

        void Application_EndRequest(object sender, EventArgs e)
        {
        }

        void Application_BeginRequest(object sender, EventArgs e)
        {
            try
            {
                HttpRequest request = ((HttpApplication)sender).Request;
                string ip = request.UserHostAddress;
                string INITD = request.Form["INTID"];
                string interactionType = request.Form["interactionType"];
                string ANI = request.Form["ANI"];
                string DNIS = request.Form["DNIS"];
                oInboundCall.agentID = request.Form["agentId"] != null ? int.Parse(request.Form["agentId"]) : 0;
                oInboundCall.CompanyID = request.Form["companyId"] != null ? int.Parse(request.Form["companyId"]) : 0;
                HttpApplication application = (HttpApplication)sender;
                HttpContext context = application.Context;
                string filePath = context.Request.FilePath;
                string fileExtension = VirtualPathUtility.GetExtension(filePath);
                string SesID = request.Form["sessionId"];
                if (fileExtension.Equals(".aspx") && request.Form.Count > 0)
                {
                    oInboundCall.WriteEvent("ZohoBroker Inter: " + interactionType + " Agent: " + oInboundCall.agentID);
                    string interType = request.Form["interactionType"];
                    string userid = "";
                    string custNumber;
                    dbAccess db = new dbAccess();
                    string oInstance = "";
                    if (oInboundCall.CompanyID != 0) oInstance = db.FindPod(oInboundCall.CompanyID.ToString(),0);
                    else oInstance = db.FindPod(request.Form["tpiauthtoken"].ToString(), 1);
                    oInboundCall.WriteEvent("Instance: " + oInstance);
                    oInboundCall.instance = oInstance;
                    switch (oInstance)
                    {
                        case "PODA":
                            oInboundCall.connString = System.Configuration.ConfigurationManager.ConnectionStrings["connStringPODA"].ConnectionString;
                            break;
                        case "PODC":
                            oInboundCall.connString = System.Configuration.ConfigurationManager.ConnectionStrings["connStringPODC"].ConnectionString;
                            break;
                        case "HQ":
                            oInboundCall.connString = System.Configuration.ConfigurationManager.ConnectionStrings["connStringHQ"].ConnectionString;
                            break;
                        default:
                            oInboundCall.connString = "Not Found";
                            break;
                    }
                    if (oInboundCall.connString != "Not Found")
                    {
                        switch (interType)
                        {
                            case "1":
                                if (oInboundCall.CheckAccountstatus(oInboundCall.agentID.ToString(), 0) == "Active")
                                {
                                    oInboundCall.WriteEvent("Inbound Call");
                                    res = oInboundCall.CallReceived(interType, oInboundCall.agentID, ANI, DNIS, INITD, ip);
                                    res = oInboundCall.WaitForAction(INITD, 0, ANI, oInboundCall.CompanyID);
                                }
                                break;
                            case "13":
                            case "12":
                            case "8":
                                if (interType == "13") userid = request.Form["from"];
                                else userid = request.Form["agentid"];
                                if (oInboundCall.CheckAccountstatus(oInboundCall.agentID.ToString(), 0) == "Active")
                                {
                                    custNumber = request.Form["to"];
                                    if (interType != "12")  oInboundCall.ANI = custNumber;
                                    if (interType != "12") res = oInboundCall.CallDailedCCA(userid, custNumber, request, 0, oInboundCall.CompanyID);
                                    else res = oInboundCall.CallDailedCCA(userid, ANI, request, 999, oInboundCall.CompanyID);
                                    if (File.Exists(path))
                                    {
                                        File.Delete(path);
                                        if (!File.Exists(path)) oInboundCall.WriteEvent("Temp File Delete");
                                    }

                                }
                                break;
                            case "9":
                                if (request.Form["predictiveContactId"] != null)
                                {
                                    userid = request.Form["from"];
                                    if (oInboundCall.CheckAccountstatus(oInboundCall.agentID.ToString(), 0) == "Active")
                                    {

                                        custNumber = request.Form["to"];
                                        oInboundCall.ANI = custNumber;
                                        res = oInboundCall.CallDailedCCA(userid, custNumber, request, 0, oInboundCall.CompanyID);
                                    }
                                }
                                break;
                            default:
                                if (request.Form.Count == 5)
                                {
                                    oInboundCall.WriteEvent("ClickTodial");
                                    //using (StreamWriter sw = File.CreateText(path))
                                    //{
                                    //    sw.WriteLine("ZohoclickTodial");
                                    //}
                                    //if (File.Exists(path)) oInboundCall.WriteEvent("Temp File Created");
                                    userid = request.Form["userid"];
                                    oInboundCall.WriteEvent("ClickTodial UserId: " + userid);
                                    if (oInboundCall.CheckAccountstatus(userid, 1) == "Active")
                                    {
                                        custNumber = request.Form["customernumber"];
                                        oInboundCall.ANI = custNumber;
                                        oInboundCall.WriteEvent("Click2Dial Make the call");
                                        oInboundCall.WriteEvent("Click2Dial Instance: " + oInboundCall.instance);
                                        res = oInboundCall.CallDailed(userid, custNumber, request, oInboundCall.instance);
                                    }
                                }
                                break;
                        }

                    }
                    else oInboundCall.WriteEvent("Instance not found: ");
                }
            }
            catch (Exception ex)
            {
                oInboundCall.WriteEvent("Click2Call Error: " + ex.Message);
            }

        }

    }

}
