﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;


namespace ZohoBroker
{
    public class dbAccess
    {
        public static string connString;
        private static System.Configuration.Configuration rootWebConfig = System.Web.Configuration.WebConfigurationManager.OpenWebConfiguration("/MyWebSiteRoot");
        static string DatabaseConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["connStringHQ"].ConnectionString;
        private SqlConnection conn = new SqlConnection(DatabaseConnectionString);
        private SqlCommand objCommand = new SqlCommand();
        private SqlDataReader objDataReader;

        public SqlDataReader ObjDataReader
        {
            get { return objDataReader; }
        }

        private object result;

        public object Result
        {
            get { return result; }
        }

        public void ExecuteCommand(string sqlCommand, System.Collections.Generic.List<System.Data.SqlClient.SqlParameter> Parameters)
        {
            objCommand.CommandType = System.Data.CommandType.Text;
            objCommand.CommandText = sqlCommand;
            objCommand.Connection = conn;
            if (Parameters != null)
            {
                objCommand.Parameters.Clear();
                objCommand.Parameters.AddRange(Parameters.ToArray());
            }
            if (conn.State == System.Data.ConnectionState.Open) conn.Close();
            conn.Open();
            result = objCommand.ExecuteScalar();
            conn.Close();
        }

        public void ExecuteReader(string sqlCommand, System.Collections.Generic.List<System.Data.SqlClient.SqlParameter> Parameters)
        {
            objCommand.CommandType = System.Data.CommandType.Text;
            objCommand.CommandText = sqlCommand;
            objCommand.Connection = conn;
            if (Parameters != null)
            {
                objCommand.Parameters.Clear();
                objCommand.Parameters.AddRange(Parameters.ToArray());
            }
            conn.Open();
            objDataReader = objCommand.ExecuteReader();
        }

        internal string FindPod(string CompanyID, int opt)
        {
            try
            {
                string PodResult = "";
            DatabaseConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["connStringMain"].ConnectionString;
            conn.ConnectionString = DatabaseConnectionString;
            objCommand.CommandType = System.Data.CommandType.Text;
            if (opt == 0) objCommand.CommandText = "Select Instance From ZohoAccounts where CompanyId = " + CompanyID;
            else objCommand.CommandText = "Select Instance From ZohoAccounts Where rtrim(ltrim(AuthToken)) = rtrim(ltrim('" + CompanyID + "'))";
            objCommand.Connection = conn;
            if (conn.State == System.Data.ConnectionState.Open) conn.Close();
            conn.Open();
            PodResult = objCommand.ExecuteScalar().ToString();
            conn.Close();
            return PodResult;
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
                return "";
            }

        }
    }
}